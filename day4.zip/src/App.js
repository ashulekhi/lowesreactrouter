import logo from './logo.svg';
import './App.css';
import Home from "./Home"
import Meeting from './Meeting';
import Login from './Login';
import Trainees from './Trainees';
import Userlist from './Userlist';
import Signup from './Signup';

function App() {
  return (
    <div className="App">
      <Signup />
    </div>
  );
}

export default App;

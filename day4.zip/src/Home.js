import axios from "axios"
import User from "./User"
import { useEffect, useState } from "react"
import List from "./List"

function Home(){
    var [users,setUsers] = useState([])

    useEffect(()=>{
       getUsers() 
    }, [])

    function getUsers(){
        axios({
            method:"get",
            url:"http://localhost:5000/allusers"
        }).then((response)=>{
           setUsers(response.data.data)
        })
    }
    
    return (
        <div>
           <List />
           
        </div>
    )
}

export default Home


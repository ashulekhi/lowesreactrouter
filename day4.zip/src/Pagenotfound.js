function Pagenotfound(){
    return (
        <div className="container">
            <img  src="/404.png" className="image-fluid w-100"></img>

        </div>
    )
}
export default Pagenotfound